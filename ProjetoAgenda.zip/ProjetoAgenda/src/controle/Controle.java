/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.io.IOException;
import java.util.ArrayList;
import modelos.Icrud;
import modelos.Contato;
import persistencia.ContatoDao;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;

public class Controle implements Icrud{
    //Atributos
    private Icrud c = new ContatoDao();
    
    //Metodos
    public void Controle(){
    }
    
    @Override
    public void incluir(Contato objeto) throws Exception{
        try {
            String erro = verificar(objeto);           
            if(!erro.isEmpty())throw new Exception(erro);            
            c.incluir(objeto);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(String nome) throws Exception{
        try {
            String erro = "";
            if(!erro.isEmpty())throw new Exception("Insira o nome do cliente a ser excluido\n");   
            c.excluir(nome);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void alterar(Contato objeto) throws Exception {
        try {
            String erro = verificar(objeto);           
            if(!erro.isEmpty())throw new Exception(erro);    
            c.alterar(objeto);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public ArrayList<Contato> listar() throws Exception {
        try {             
            return c.listar();
        } catch (Exception erro) {
            throw erro;
        }
    }

    private String verificar(Contato objeto){
        String erro = "";
        if(objeto.getNomeCompleto().isEmpty()) erro += "Esse campo (nome) e obrigatorio, nao pode estar vazio.\n";
        if(!objeto.getNomeCompleto().matches("^[a-zA-Z ]+$")) erro += "Esse campo (nome) somente aceita letras\n";
        if(objeto.getEmail().isEmpty()) erro += "Esse campo (email) e obrigatorio, nao pode estar vazio\n.";
        if(objeto.getTelefone().getDdi().isEmpty()) erro += "Esse campo (telefone) e obrigatorio, nao pode estar vazio, e deve estar de acordo (ddi ddd numero)";
        if(objeto.getTelefone().getDdd().isEmpty()) erro += "Esse campo (telefone) e obrigatorio, nao pode estar vazio, e deve estar de acordo (ddi ddd numero)";
        if(objeto.getTelefone().getNumero().isEmpty()) erro += "Esse campo (telefone) e obrigatorio, nao pode estar vazio, e deve estar de acordo (ddi ddd numero)";
        if(objeto.getEndereco().isEmpty()) erro += "Esse campo (endereco) e obrigatorio, nao pode estar vazio.\n";
        if(!objeto.getEmail().matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) erro += "Esse campo (email) recebeu um email invalido.\n";
        String ddi = objeto.getTelefone().getDdi();
        if(!ddi.matches("[0-9]+")) erro += "Esse campo (DDI) somente aceita numeros.\n";
        String ddd = objeto.getTelefone().getDdd();
        if(!ddd.matches("[0-9]+")) erro += "Esse campo (DDD) somente aceita numeros.\n";
        String numero = objeto.getTelefone().getNumero();
        if(!numero.matches("[0-9]+")) erro += "Esse campo (numero) somente aceita numeros.\n";
        return erro;

    }
    
    @Override
    public String consultar(String nome) throws Exception {
        try{
        if (nome == null || nome.trim().isEmpty()) {
            throw new Exception("Nome não pode estar vazio!");
        }
        return c.consultar(nome);
        }catch(Exception erro){
            throw erro;
        }
    }
    
    public void gerarPDF(String caminho) throws IOException, Exception {
        PdfWriter writer = new PdfWriter(caminho);
        com.itextpdf.kernel.pdf.PdfDocument pdf = new com.itextpdf.kernel.pdf.PdfDocument(writer);
        Document document = new Document(pdf);

        Paragraph titulo = new Paragraph("Lista de Contatos");
        document.add(titulo);

        float[] pointColumnWidths = {150F, 150F, 200F, 250F};
        Table table = new Table(pointColumnWidths);

        table.addCell(new Cell().add(new Paragraph("Nome")));
        table.addCell(new Cell().add(new Paragraph("Telefone")));
        table.addCell(new Cell().add(new Paragraph("Email")));
        table.addCell(new Cell().add(new Paragraph("Endereço")));

        ArrayList<Contato> contatos = listar();
        for (Contato contato : contatos) {
            table.addCell(new Cell().add(new Paragraph(contato.getNomeCompleto())));
            table.addCell(new Cell().add(new Paragraph(contato.getTelefone().toString())));
            table.addCell(new Cell().add(new Paragraph(contato.getEmail())));
            table.addCell(new Cell().add(new Paragraph(contato.getEndereco().toString())));
        }

        document.add(table);
        document.close();
    }
    
}
