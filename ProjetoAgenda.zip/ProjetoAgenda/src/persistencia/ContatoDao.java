/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import modelos.Contato;
import modelos.Telefone;

public class ContatoDao implements modelos.Icrud {
    
    @Override
    public void incluir(Contato contato) throws Exception {
        // Converte os componentes do telefone para string
        String ddi = contato.getTelefone().getDdi();
        String ddd = contato.getTelefone().getDdd();
        String numero = contato.getTelefone().getNumero();

        // Concatena as partes do número de telefone com um espaço entre elas
        String tel = ddi + " " + ddd + " " + numero;

        // Cria uma representação de string do contato
        String contatoStr = contato.getNomeCompleto().toUpperCase() + ";" + tel + ";" + contato.getEmail() + ";" + contato.getEndereco();

        // Verifica se o arquivo existe e cria um novo se não existir
        File file = new File("agenda.csv");
        if (!file.exists()) {
            file.createNewFile();
        }

        // Lê todos os contatos do arquivo
        ArrayList<String> contatos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                contatos.add(linha);
            }
        } catch (Exception erro) {
            throw new Exception("Contato - Incluir - erro ao abrir o arquivo!");
        }

        // Adiciona o novo contato à lista
        contatos.add(contatoStr);

        // Ordena a lista em ordem alfabética
        Collections.sort(contatos);

        // Escreve a lista ordenada de volta no arquivo
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, false))) {
            for (String c : contatos) {
                bw.write(c);
                bw.newLine();
            }
        } catch (Exception erro) {
            throw new Exception("Contato - Incluir - erro ao reescrever o arquivo!");
        }
    }

    @Override
    public void excluir(String nome) throws Exception {
        // Lê todos os contatos do arquivo CSV
        ArrayList<String> linhas = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("agenda.csv"))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                linhas.add(linha);
            }
        } catch (Exception erro) {
            throw new Exception("Contato - Excluir - erro ao abrir o arquivo!");
        }

        // Procura o contato pelo nome e remove da lista
        linhas.removeIf(linha -> linha.split(";")[0].equalsIgnoreCase(nome));

        // Reescreve o arquivo CSV com os contatos restantes
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("agenda.csv", false))) {
            for (String linha : linhas) {
                bw.write(linha);
                bw.newLine();
            }
        } catch (Exception erro) {
            throw new Exception("Contato - Excluir - erro ao reescrever o arquivo!");
        }
    }

    @Override
    public ArrayList<Contato> listar() throws Exception {
        ArrayList<Contato> contatos = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("agenda.csv"))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] contatoData = linha.split(";");
                if (contatoData.length == 4) {
                    String nome = contatoData[0];
                    String[] telefoneData = contatoData[1].split(" ");
                    Telefone telefone = new Telefone(telefoneData[0], telefoneData[1], telefoneData[2]);
                    String email = contatoData[2];
                    String endereco = contatoData[3];
                    Contato contato = new Contato(nome, telefone, email, endereco);
                    contatos.add(contato);
                } else {
                    throw new Exception("Erro no ContatoDao - Listar - linha do CSV não tem o número correto de campos!");
                }
            }
        } catch (FileNotFoundException e) {
            throw new Exception("Erro no ContatoDao - Listar - arquivo não encontrado!");
        } catch (IOException e) {
            throw new Exception("Erro no ContatoDao - Listar - erro ao ler o arquivo!");
        }

        // Ordena a lista de contatos em ordem alfabética
        Collections.sort(contatos, new Comparator<Contato>() {
            @Override
            public int compare(Contato c1, Contato c2) {
                return c1.getNomeCompleto().compareTo(c2.getNomeCompleto());
            }
        });

        return contatos;
    }


    @Override
    public String consultar(String nome) throws Exception {
        ArrayList<String> linhas = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("agenda.csv"))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                linhas.add(linha);
            }
        } catch (IOException e) {
            throw new Exception("Erro ao abrir o arquivo para consulta: " + e.getMessage());
        }

        for (String linha : linhas) {
            String[] dadosContato = linha.split(";");
            if (dadosContato.length == 6 && dadosContato[0].equalsIgnoreCase(nome)) {
                Telefone telefone = new Telefone(dadosContato[3], dadosContato[4], dadosContato[5]);
                return String.format("%s,%s,%s,%s", 
                    dadosContato[0], dadosContato[1], dadosContato[2], telefone.toString());
            }
        }

        throw new Exception("Contato não encontrado!");
    }

    
    @Override
    public void alterar(Contato contato) throws Exception {
        // Primeiro, obtemos o contato existente com o mesmo nome
        String detalhesContatoExistente = consultar(contato.getNomeCompleto());
        if (detalhesContatoExistente == null) {
            throw new Exception("Contato não encontrado");
        }

        // Em seguida, excluímos o contato existente com o mesmo nome
        excluir(contato.getNomeCompleto());

        // Finalmente, incluímos o novo contato com os detalhes atualizados
        incluir(contato);
    }





}
