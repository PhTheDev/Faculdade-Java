/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelos;

import java.util.ArrayList;

public interface Icrud {
    public void incluir(Contato contato) throws Exception;    
    public void excluir(String nome) throws Exception;   
    public void alterar(Contato Contato) throws Exception;    
    public String consultar(String nome)throws Exception;    
    public ArrayList<Contato> listar()throws Exception;
    
}
