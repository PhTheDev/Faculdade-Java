/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package visao;

import controle.Controle;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import modelos.*;


public class JFrame_Principal extends javax.swing.JFrame {

    /**
     * Creates new form JFrame_Principal
     */
    public JFrame_Principal() {
        initComponents();
        setLocationRelativeTo(null);
        setupEmailFieldPlaceholder();
        
        // Adiciona um DocumentListener ao campo de texto nomeCompleto
        JTextField_Consultar.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void changedUpdate(DocumentEvent e) {
                atualizarTabela();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                atualizarTabela();
            }
            @Override
            public void insertUpdate(DocumentEvent e) {
                atualizarTabela();
            }

            public void atualizarTabela() {
                // Obtém o texto atual do campo de texto nomeCompleto
                String nome = JTextField_Consultar.getText().toUpperCase();

                // Cria uma instância da classe Controle
                Controle controle = new Controle();

                try {
                    // Obtém a lista de todos os contatos
                    ArrayList<Contato> contatos = controle.listar();

                    // Filtra a lista de contatos para incluir apenas aqueles cujo nome começa com o texto inserido
                    ArrayList<Contato> contatosFiltrados = new ArrayList<>();
                    for (Contato contato : contatos) {
                        if (contato.getNomeCompleto().startsWith(nome)) {
                            contatosFiltrados.add(contato);
                        }
                    }

                    // Atualiza a tabela com os contatos filtrados
                    DefaultTableModel model = (DefaultTableModel) JTable_Tabela.getModel();
                    model.setRowCount(0); // Limpa a tabela antes de adicionar novos dados
                    for (Contato contato : contatosFiltrados) {
                        String nomeContato = contato.getNomeCompleto();
                        String telefone = contato.getTelefone().toString();
                        String email = contato.getEmail();
                        String endereco = contato.getEndereco();
                        model.addRow(new Object[] {nomeContato, telefone, email, endereco});
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(rootPane, ex.getMessage());
                }
            }
        });
        
        JTable_Tabela.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
        @Override
        public void valueChanged(ListSelectionEvent event) {
            if (JTable_Tabela.getSelectedRow() != -1) {
                // Obtém os dados do contato selecionado
                int row = JTable_Tabela.getSelectedRow();
                String nome = JTable_Tabela.getValueAt(row, 0).toString();
                String telefone = JTable_Tabela.getValueAt(row, 1).toString();
                String email = JTable_Tabela.getValueAt(row, 2).toString();
                String enderecoCompleto = JTable_Tabela.getValueAt(row, 3).toString();

                // Divide o endereço em seus componentes
                String[] enderecoParts = enderecoCompleto.split(",");
                String logradouro = enderecoParts[0];
                String numerocasa = enderecoParts[1];
                String complemento = enderecoParts[2];
                String cidade = enderecoParts[3];
                String estado = enderecoParts[4];
                String cep = enderecoParts[5];

                // Preenche os campos JTextField com as informações do contato
                JTextField_Nome.setText(nome);
                JTextField_Telefone.setText(telefone);
                JTextField_Email.setText(email);
                JTextField_Logradouro.setText(logradouro);
                JTextField_Numero.setText(numerocasa);
                JTextField_Complemento.setText(complemento);
                JTextField_Cidade.setText(cidade);
                JTextField_Estado.setText(estado);
                JTextField_CEP.setText(cep);
            }
        }
    });

        JTable_Tabela.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            if (!event.getValueIsAdjusting() && JTable_Tabela.getSelectedRow() != -1) {
                int row = JTable_Tabela.getSelectedRow();
                JTextField_Nome.setText(JTable_Tabela.getValueAt(row, 0).toString());
                JTextField_Telefone.setText(JTable_Tabela.getValueAt(row, 1).toString());
                JTextField_Email.setText(JTable_Tabela.getValueAt(row, 2).toString());
                String enderecoCompleto = JTable_Tabela.getValueAt(row, 3).toString();
                String[] partesEndereco = enderecoCompleto.split(",");
                JTextField_Logradouro.setText(partesEndereco[0]); // Logradouro
                JTextField_Numero.setText(partesEndereco[1]); // Número
                // Verifica se o complemento existe antes de tentar usá-lo
                if (partesEndereco.length > 2) {
                    JTextField_Complemento.setText(partesEndereco[2]); // Complemento
                } else {
                    JTextField_Complemento.setText(""); // Limpa o campo se não houver complemento
                }
                JTextField_Cidade.setText(partesEndereco[3]); // Cidade
                JTextField_Estado.setText(partesEndereco[4]); // Estado
                JTextField_CEP.setText(partesEndereco[5]); // CEP
            }
        }
        });
    }
    
    private void setupEmailFieldPlaceholder() {
        JTextField_Email.setText("exemplo@dominio.com.br");
        JTextField_Email.setForeground(Color.GRAY);
        JTextField_Email.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (JTextField_Email.getText().equals("exemplo@dominio.com.br")) {
                    JTextField_Email.setText("");
                    JTextField_Email.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (JTextField_Email.getText().isEmpty()) {
                    JTextField_Email.setForeground(Color.GRAY);
                    JTextField_Email.setText("exemplo@dominio.com.br");
                }
            }
        });
    }
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField3 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        JTextField_Email = new javax.swing.JTextField();
        JTextField_Nome = new javax.swing.JTextField();
        JButton_Alterar = new javax.swing.JButton();
        JButton_Incluir = new javax.swing.JButton();
        JButton_Listar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTable_Tabela = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        JTextField_Logradouro = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        JTextField_Numero = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        JTextField_Complemento = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        JTextField_Cidade = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        JTextField_Estado = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        JTextField_CEP = new javax.swing.JTextField();
        JTextField_Telefone = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        JButton_INFO = new javax.swing.JButton();
        JButton_Excluir = new javax.swing.JButton();
        JTextField_Consultar = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        JButton_PDF = new javax.swing.JButton();

        jTextField3.setText("jTextField1");

        jLabel13.setText("jLabel13");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 0));
        jLabel1.setText("AGENDA");

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 51));
        jLabel2.setText("Nome Completo:");

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 51));
        jLabel3.setText("Telefone (ddi ddd numero):");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 51));
        jLabel4.setText("Email:");

        JTextField_Email.setForeground(new java.awt.Color(0, 0, 0));

        JButton_Alterar.setBackground(new java.awt.Color(0, 153, 0));
        JButton_Alterar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        JButton_Alterar.setForeground(new java.awt.Color(255, 255, 255));
        JButton_Alterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Hopstarter-Soft-Scraps-Pen-Green.256 (1).png"))); // NOI18N
        JButton_Alterar.setText("Alterar");
        JButton_Alterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AlterarActionPerformed(evt);
            }
        });

        JButton_Incluir.setBackground(new java.awt.Color(0, 153, 0));
        JButton_Incluir.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        JButton_Incluir.setForeground(new java.awt.Color(255, 255, 255));
        JButton_Incluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/add-icon (2).png"))); // NOI18N
        JButton_Incluir.setText("Incluir");
        JButton_Incluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_IncluirActionPerformed(evt);
            }
        });

        JButton_Listar.setBackground(new java.awt.Color(0, 153, 0));
        JButton_Listar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        JButton_Listar.setForeground(new java.awt.Color(255, 255, 255));
        JButton_Listar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Icons8-Windows-8-Food-List-Ingredients.512 (1).png"))); // NOI18N
        JButton_Listar.setText("Listar");
        JButton_Listar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_ListarActionPerformed(evt);
            }
        });

        JTable_Tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome completo", "Telefone", "Email", "Endereço"
            }
        ));
        jScrollPane1.setViewportView(JTable_Tabela);

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 51));
        jLabel5.setText("ENDEREÇO:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 51));
        jLabel6.setText("Logradouro:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 51));
        jLabel7.setText("Numero:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 51));
        jLabel8.setText("Complemento:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 51));
        jLabel9.setText("Cidade:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 153, 51));
        jLabel10.setText("Estado:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 153, 0));
        jLabel11.setText("CEP:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 153, 0));
        jLabel12.setText("ESMERALDINA");

        JButton_INFO.setBackground(new java.awt.Color(0, 153, 0));
        JButton_INFO.setForeground(new java.awt.Color(255, 255, 255));
        JButton_INFO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Fa-Team-Fontawesome-FontAwesome-Exclamation.512 (1).png"))); // NOI18N
        JButton_INFO.setText("INFO");
        JButton_INFO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_INFOActionPerformed(evt);
            }
        });

        JButton_Excluir.setBackground(new java.awt.Color(0, 153, 0));
        JButton_Excluir.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        JButton_Excluir.setForeground(new java.awt.Color(255, 255, 255));
        JButton_Excluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Royalflushxx-Systematrix-Trash.256 (1).png"))); // NOI18N
        JButton_Excluir.setText("Excluir");
        JButton_Excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_ExcluirActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 153, 51));
        jLabel14.setText("Consultar Nome:");

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pngwing.com (1).png"))); // NOI18N

        JButton_PDF.setBackground(new java.awt.Color(0, 153, 0));
        JButton_PDF.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JButton_PDF.setForeground(new java.awt.Color(255, 255, 255));
        JButton_PDF.setText("PDF");
        JButton_PDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_PDFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(JButton_Incluir, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(JButton_Excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4)))
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JTextField_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JTextField_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JTextField_Telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(JButton_Alterar, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(JButton_Listar, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(JTextField_Cidade, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(JTextField_Logradouro, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(JTextField_Numero, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel8))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel10)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(JTextField_Estado, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(JTextField_Complemento, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(JTextField_CEP, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(187, 187, 187))
            .addComponent(jSeparator1)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 121, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(775, 775, 775))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jLabel12)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JButton_INFO)
                        .addGap(55, 55, 55))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(324, 324, 324)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JTextField_Consultar, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(JButton_PDF, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JButton_INFO, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addGap(77, 77, 77)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(JTextField_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel15)))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(JTextField_Telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(JTextField_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(JTextField_Logradouro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(JTextField_Numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(JTextField_Complemento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(JTextField_Cidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(JTextField_Estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(JTextField_CEP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Alterar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JButton_Incluir, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JButton_Listar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JButton_Excluir, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JTextField_Consultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(JButton_PDF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JButton_IncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_IncluirActionPerformed
        String nome = JTextField_Nome.getText();
        String telefoneCompleto = JTextField_Telefone.getText();
        String email = JTextField_Email.getText();
        String endereco;
        //Componentes do endereço
        String logradouro = JTextField_Logradouro.getText();
        String numerocasa = JTextField_Numero.getText();
        String complemento = JTextField_Complemento.getText();
        String cidade = JTextField_Cidade.getText();
        String estado = JTextField_Estado.getText();
        String cep = JTextField_CEP.getText();
        if("".equals(JTextField_Complemento.getText())){
            endereco = logradouro + "," + numerocasa + "," + "SEM COMPLEMENTO" + "," + cidade + "," + estado + "," + cep;
        }else{
            endereco = logradouro + "," + numerocasa + "," + complemento + "," + cidade + "," + estado + "," + cep;
        }

        // Divide o telefone em DDI, DDD e número
        String[] partes = telefoneCompleto.split(" ");
        String ddi = partes[0];
        String ddd = partes[1];
        String numero = partes[2];

        // Cria um novo objeto Telefone com os dados inseridos
        Telefone tel = new Telefone(ddi, ddd, numero);

        // Cria um novo objeto Contato com os dados inseridos
        Contato cont = new Contato(nome, tel, email, endereco);

        try {
            // Cria uma instância da classe ContatoDao
            Controle controle = new Controle();

            // Inclui o novo contato usando o método incluir da classe ContatoDao
            controle.incluir(cont);
            
            JOptionPane.showMessageDialog(rootPane, "Incluido Com Successo!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }//GEN-LAST:event_JButton_IncluirActionPerformed

    private void JButton_ListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_ListarActionPerformed
        // Cria uma instância da classe ContatoDao
        Controle controle = new Controle();

        // Obtém o modelo da tabela
        DefaultTableModel model = (DefaultTableModel) JTable_Tabela.getModel();
        model.setRowCount(0); // Limpa a tabela antes de adicionar novos dados

        try {
            // Chama o método listar da classe ContatoDao para obter a lista de contatos
            ArrayList<Contato> contatos = controle.listar();

            // Adiciona cada contato à tabela
            for (Contato contato : contatos) {
                String nome = contato.getNomeCompleto();
                String telefone = contato.getTelefone().toString();
                String email = contato.getEmail();
                String endereco = contato.getEndereco();
                model.addRow(new Object[] {nome, telefone, email, endereco});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }//GEN-LAST:event_JButton_ListarActionPerformed

    private void JButton_AlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AlterarActionPerformed
        if (JTable_Tabela.getSelectedRow() != -1) {
            // Obtém o nome do contato selecionado
            int row = JTable_Tabela.getSelectedRow();
            String nomeOriginal = JTable_Tabela.getValueAt(row, 0).toString();

            // Obtém os novos dados do contato dos campos JTextField
            String nome = JTextField_Nome.getText();
            String telefoneStr = JTextField_Telefone.getText().replaceAll("[^0-9]", ""); // Remove caracteres não numéricos
            String email = JTextField_Email.getText();
            String endereco;
            //Componentes do endereço
            String logradouro = JTextField_Logradouro.getText();
            String numerocasa = JTextField_Numero.getText();
            String complemento = JTextField_Complemento.getText();
            String cidade = JTextField_Cidade.getText();
            String estado = JTextField_Estado.getText();
            String cep = JTextField_CEP.getText();
            if("".equals(JTextField_Complemento.getText())){
                endereco = logradouro + "," + numerocasa + "," + "SEM COMPLEMENTO" + "," + cidade + "," + estado + "," + cep;
            }else{
                endereco = logradouro + "," + numerocasa + "," + complemento + "," + cidade + "," + estado + "," + cep;
            }

            // Converte a String do telefone para o objeto Telefone
            String ddi = telefoneStr.substring(0, 2);
            String ddd = telefoneStr.substring(2, 4);
            String numero = telefoneStr.substring(4);
            Telefone telefone = new Telefone(ddi, ddd, numero);

            // Cria um novo Contato com os novos dados
            Contato contato = new Contato(nome, telefone, email, endereco);

            try {
                // Cria uma instância da classe ContatoDao
                Controle controle = new Controle();

                // Primeiro, exclui o contato original
                controle.excluir(nomeOriginal);

                // Em seguida, inclui o novo contato com os detalhes atualizados
                controle.incluir(contato);

                // Limpa a tabela
                DefaultTableModel model = (DefaultTableModel) JTable_Tabela.getModel();
                model.setRowCount(0);

                // Chama o método listar da classe ContatoDao para obter a lista de contatos
                ArrayList<Contato> contatos = controle.listar();

                // Adiciona cada contato à tabela
                for (Contato c : contatos) {
                    String contatoNome = c.getNomeCompleto();
                    String telefoneContato = c.getTelefone().toString();
                    String contatoEmail = c.getEmail();
                    String contatoEndereco = c.getEndereco();
                    model.addRow(new Object[] {contatoNome, telefoneContato, contatoEmail, contatoEndereco});
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Nenhum contato selecionado");
        }
    }//GEN-LAST:event_JButton_AlterarActionPerformed

    private void JButton_INFOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_INFOActionPerformed
        String autor = "Nome do Autor: Pedro Henrique Faria";
        String github = "GitHub: https://github.com/PhTheDev";
        String aluno = "Aluno de Eng. da Computação na Pontifícia Universidade Católica de Goiás";

        String message = "<html><body>" + autor + "<br>" + github + "<br>" + aluno + "</body></html>";

        try {
            // Substitua "caminho/para/sua/imagem.jpg" pelo caminho real para sua imagem
            Image image = ImageIO.read(new File("C:\\Users\\faria\\Desktop\\ProjetoAgenda\\src\\imagens\\FOTO.jpg"));

            // Redimensiona a imagem para 100x100 pixels
            Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_DEFAULT);
            ImageIcon icon = new ImageIcon(scaledImage);

            // Cria um JLabel para a imagem
            JLabel labelImage = new JLabel();
            labelImage.setIcon(icon);

            // Cria um JLabel para o texto
            JLabel labelText = new JLabel(message);

            // Cria um JPanel para conter ambos
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(labelImage, BorderLayout.WEST);
            panel.add(labelText, BorderLayout.CENTER);

            JOptionPane.showMessageDialog(this, panel, "Informações", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao ler a imagem", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_JButton_INFOActionPerformed

    private void JButton_ExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_ExcluirActionPerformed
        if (JTable_Tabela.getSelectedRow() != -1) {
            // Obtém os dados do contato selecionado
            int row = JTable_Tabela.getSelectedRow();
            String nome = JTable_Tabela.getValueAt(row, 0).toString();

            // Pergunta ao usuário se ele realmente quer excluir o contato
            int resposta = JOptionPane.showConfirmDialog(null, "Você realmente quer excluir o contato " + nome + "?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (resposta == JOptionPane.YES_OPTION) {
                try {
                    // Cria uma instância do Controle
                    Controle controle = new Controle();

                    // Chama a função excluir
                    controle.excluir(nome);

                    // Limpa a tabela
                    DefaultTableModel model = (DefaultTableModel) JTable_Tabela.getModel();
                    model.setRowCount(0);

                    // Chama o método listar da classe ContatoDao para obter a lista de contatos
                    ArrayList<Contato> contatos = controle.listar();

                    // Adiciona cada contato à tabela
                    for (Contato contato : contatos) {
                        String contatoNome = contato.getNomeCompleto();
                        String telefone = contato.getTelefone().toString();
                        String contatoEmail = contato.getEmail();
                        String endereco = contato.getEndereco();
                        model.addRow(new Object[] {contatoNome, telefone, contatoEmail, endereco});
                    }
                    JOptionPane.showMessageDialog(rootPane, "Excluido com successo!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(rootPane, ex.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Nenhum contato selecionado");
        }
    }//GEN-LAST:event_JButton_ExcluirActionPerformed

    private void JButton_PDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_PDFActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Salvar PDF");
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            if (!filePath.endsWith(".pdf")) {
                filePath += ".pdf";
            }

            // Chamar o método de geração de PDF
                Controle controle = new Controle();
            try {
                controle.gerarPDF(filePath);
            } catch (Exception ex) {
                Logger.getLogger(JFrame_Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
                
    }
    }//GEN-LAST:event_JButton_PDFActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrame_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrame_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrame_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrame_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JFrame_Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Alterar;
    private javax.swing.JButton JButton_Excluir;
    private javax.swing.JButton JButton_INFO;
    private javax.swing.JButton JButton_Incluir;
    private javax.swing.JButton JButton_Listar;
    private javax.swing.JButton JButton_PDF;
    private javax.swing.JTable JTable_Tabela;
    private javax.swing.JTextField JTextField_CEP;
    private javax.swing.JTextField JTextField_Cidade;
    private javax.swing.JTextField JTextField_Complemento;
    private javax.swing.JTextField JTextField_Consultar;
    private javax.swing.JTextField JTextField_Email;
    private javax.swing.JTextField JTextField_Estado;
    private javax.swing.JTextField JTextField_Logradouro;
    private javax.swing.JTextField JTextField_Nome;
    private javax.swing.JTextField JTextField_Numero;
    private javax.swing.JTextField JTextField_Telefone;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables

}
